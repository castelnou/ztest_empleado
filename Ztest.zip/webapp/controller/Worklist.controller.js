sap.ui.define([
	"test/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"test/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/MessageToast',
	'sap/m/Text',
	'sap/m/Input',
	'sap/ui/layout/HorizontalLayout',
	'sap/ui/layout/VerticalLayout'
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, History, Button, Dialog, MessageToast, Text, Input,
	HorizontalLayout, VerticalLayout) {
	"use strict";

	return BaseController.extend("test.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;

			sap.ui.getCore().setModel(oTable, "tablaa");

			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			sap.ui.getCore().setModel(oViewModel, "globalModel");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			//	this._showObject(oEvent.getSource());

			//	sap.ui.getCore().byId("")
		},

		onCreate: function(oEvent) {

			var dialog = new Dialog({
				title: 'Empleado',
				type: 'Message',
				content: [
					new HorizontalLayout({
						content: [
							new VerticalLayout({
								width: '200px',
								content: [
									new Input('in1', {
										width: '200px',
										placeholder: "Nombre"
									}),
									new Input('in2', {
										width: '200px',
										placeholder: "Apellido"
									}),
									new Input('in3', {
										width: '200px',
										placeholder: "Departamento"
									}),
									new Input('in4', {
										width: '200px',
										placeholder: "Sueldo"
									})
								]
							})
						]
					})
				],
				beginButton: new Button({
					text: 'Crear',
					type: 'Accept',
					press: function() {

						var oEntry = {};

						oEntry.Nombre = sap.ui.getCore().byId("in1").getValue();
						oEntry.Apellido = sap.ui.getCore().byId("in2").getValue();
						oEntry.Departamento = sap.ui.getCore().byId("in3").getValue();
						oEntry.Sueldo = sap.ui.getCore().byId("in4").getValue();

						OData.request({
								requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet",
								method: "GET",
								headers: {
									"X-Requested-With": "XMLHttpRequest",
									"Content-Type": "application/json",
									"DataServiceVersion": "2.0",
									"X-CSRF-Token": "Fetch"
								}
							},
							function(data, response) {
								var header_xcsrf_token = response.headers['x-csrf-token'];
								var oHeaders = {
									"x-csrf-token": header_xcsrf_token,
									'Accept': 'application/json'
								};

								OData.request({
										requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet",

										method: "POST",
										headers: oHeaders,
										data: oEntry
									},
									function(data, request) {
										MessageToast.show("Employee Created Successfully");
										var tabla = sap.ui.getCore().getModel('tablaa');
										tabla.getModel().refresh();
									},
									function(err) {
										MessageToast.show("Employee Creation Failed");
									});
							},
							function(err) {
								var request = err.request;
								var response = err.response;
								MessageToast.show("Error in Get -- Request " + request + " Response " + response);
							});

						dialog.close();
					}

				}),
				endButton: new Button({
					text: 'Cancelar',
					type: 'Reject',
					press: function() {

						dialog.close();
					}
				}),

				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");
				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Id", FilterOperator.EQ, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Id")
			});
		},

		onConfirmDialog: function(evt) {

			//	var a,b;
			//	a =	evt.getBindingContext().getProperty("Id");
			//a = this._oTable.getBinding("items");
			//	b = this.getBindingContext().getProperty("Id");
			var param = evt.getParameters().id;

			var a = sap.ui.getCore().byId(param);
			var nombre = a.getBindingContext().getProperty("Nombre");
			var sueldo = a.getBindingContext().getProperty("Sueldo");
			var departamento = a.getBindingContext().getProperty("Departamento");
			var apellido = a.getBindingContext().getProperty("Apellido");

			var dialog = new Dialog({
				title: 'Empleado',
				type: 'Message',
				content: [
					new HorizontalLayout({
						content: [
							new VerticalLayout({
								width: '200px',
								content: [
									new Input('in1', {
										width: '200px',
										placeholder: nombre
									}),
									new Input('in2', {
										width: '200px',
										placeholder: apellido
									}),
									new Input('in3', {
										width: '200px',
										placeholder: departamento
									}),
									new Input('in4', {
										width: '200px',
										placeholder: sueldo
									})
								]
							})
							/*	new VerticalLayout({
									content: [
										new Text({ text: 'Shopping Cart' }),
										new Text({ text: 'Jun 26, 2013' }),
										new Text({ text: '2' })
									]
								})*/
						]
					})

				],
				buttons: [new Button({
						text: 'Update',
						type: 'Accept',
						press: function() {

							var oEntry = {};
							var de = sap.ui.getCore().byId(param);
							var ids = de.getBindingContext().getProperty("Id");
							oEntry.Id = ids;
							var name = sap.ui.getCore().byId("in1").getValue();
							var ape = sap.ui.getCore().byId("in2").getValue();
							var depa = sap.ui.getCore().byId("in3").getValue();
							var sueld = sap.ui.getCore().byId("in4").getValue();
							if (name === "") {
								oEntry.Nombre = nombre;
							} else {
								oEntry.Nombre = name;
							}
							if (sueld === "") {
								oEntry.Sueldo = sueldo;
							} else {
								oEntry.Sueldo = sueld;
							}
							if (depa === "") {
								oEntry.Departamento = departamento;
							} else {
								oEntry.Departamento = depa;
							}
							if (ape === "") {
								oEntry.Apellido = apellido;
							} else {
								oEntry.Apellido = ape;
							}

							OData.request({
									requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet('" + ids + "')",
									method: "GET",
									headers: {
										"X-Requested-With": "XMLHttpRequest",
										"Content-Type": "application/json",
										"DataServiceVersion": "2.0",
										"X-CSRF-Token": "Fetch"
									}
								},
								function(data, response) {
									var header_xcsrf_token = response.headers['x-csrf-token'];
									var oHeaders = {
										"x-csrf-token": header_xcsrf_token,
										'Accept': 'application/json'
									};

									OData.request({
											requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet('" + ids + "')",

											method: "PUT",
											headers: oHeaders,
											data: oEntry
										},
										function(data, request) {
											MessageToast.show("Update Success");
											var tabla = sap.ui.getCore().getModel('tablaa');
											tabla.getModel().refresh();
										},
										function(err) {
											MessageToast.show("Update Failed");
										});
								},
								function(err) {
									var request = err.request;
									var response = err.response;
									MessageToast.show("Error in Get -- Request " + request + " Response " + response);
								});
							dialog.close();
						}

						/*	var sText = sap.ui.getCore().byId('in1').getValue();
							MessageToast.show('Note is: ' + sText);
							dialog.close();*/

					}),
					new Button({
						text: 'Delete',
						type: 'Reject',
						press: function() {

								var oEntry = {};
								var de = sap.ui.getCore().byId(param);
								var ids = de.getBindingContext().getProperty("Id");
								oEntry.Id = ids;

								OData.request({
										requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet('" + ids + "')",
										method: "GET",
										headers: {
											"X-Requested-With": "XMLHttpRequest",
											"Content-Type": "application/json",
											"DataServiceVersion": "2.0",
											"X-CSRF-Token": "Fetch"
										}
									},
									function(data, response) {
										var header_xcsrf_token = response.headers['x-csrf-token'];
										var oHeaders = {
											"x-csrf-token": header_xcsrf_token,
											'Accept': 'application/json'

										};

										OData.request({
												requestUri: "/sap/opu/odata/sap/ZSDN_EMPLEADO_SRV/EmpleadoSet('" + ids + "')",
												method: "DELETE",
												headers: oHeaders
											},

											function(data, request) {
												MessageToast.show("Delete Success");

												var tabla = sap.ui.getCore().getModel('tablaa');
												tabla.getModel().refresh();

												//this.onRefresh();//location.reload(true);
											},
											function(err) {
												MessageToast.show("Delete Failed");
											});
									},
									function(err) {
										var request = err.request;
										var response = err.response;
										MessageToast.show("Error in Get -- Request " + request + " Response " + response);
									}

								);

								//	sap.ui.getCore().getModel('globalModel').refresh();//sap.ui.getCore().getModel();
								//	var oModel = sap.ui.getCore().getModel("globalModel");

								dialog.close();
							}
							//var sTextn = sap.ui.getCore().byId('in1').getValue();
							//	MessageToast.show('Note is: ' + sText);

					}),

					new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					})
				],
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});