 #### WELCOME ####

This is your copy of the SAPUI5 Worklist Freestyle Application Template.
You can find the template version in the .project.json - file in your workspace

Standalone runnable files (*.html) are located in the test-folder

This application is ready for client-side build in the SAP Web IDE and deployment to ABAP/HCP repositories

Documentation of all template-app features can be found in the SAPUI5 demokit here:
https://sapui5.hana.ondemand.com/#docs/guide/a460a7348a6c431a8bd967ab9fb8d918.html


 #### Happy Development! ####